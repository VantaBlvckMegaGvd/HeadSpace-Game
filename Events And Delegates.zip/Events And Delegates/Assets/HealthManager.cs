﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;



public class HealthManager : MonoBehaviour {

	//Delegate that will be called... we need to create a method on any object that subscribes to this event that
	//matches this signature.
	public delegate void DoAOEDamangeDelegate(float amount);

	//The event we will be subscribing to
	public static event DoAOEDamangeDelegate DoAOEDamageEvent;

	public static void DoDamage(float amount)
	{
		//Have to make sure there is at least one item subscribed, otherwise, don't send the event.
		if (DoAOEDamageEvent != null)
			DoAOEDamageEvent(amount);

	}

	

}
