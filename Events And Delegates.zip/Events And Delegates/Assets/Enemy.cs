﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour {

	// Use this for initialization
	void Start () {
		HealthManager.DoAOEDamageEvent += OnAOEDamage;
	}

	private void OnDestroy()
	{
		HealthManager.DoAOEDamageEvent -= OnAOEDamage;
	}

	void OnAOEDamage(float amount)
	{
		if (FindObjectOfType<Player>().IsAffectedByAOE(transform))
		{
			print(name + ": Received " + amount + " damage");
		} else
		{
			print(name +  ": Not taking damage");
		}
		
	}

	
}
