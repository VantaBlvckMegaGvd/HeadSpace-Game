﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour {

	public float aoeRadius = 2;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetKeyDown(KeyCode.Space))
		{
			HealthManager.DoDamage(50);
		}
	}

	private void OnDrawGizmos()
	{
		Gizmos.color = new Color(1, 0, 0, 0.2f);
		Gizmos.DrawSphere(transform.position, aoeRadius);
	}

	public float GetDistance(Transform obj)
	{
		return Vector3.Distance(transform.position, obj.position);
	}

	public bool IsAffectedByAOE(Transform obj)
	{
		return (GetDistance(obj) <= aoeRadius);
	}
}
